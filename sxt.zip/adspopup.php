<script type="text/javascript">
  var uid = '228542';
  var wid = '477235';
</script>
<script type="text/javascript" src="//cdn.popcash.net/pop.js"></script>