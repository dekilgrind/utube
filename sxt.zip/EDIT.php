<?php
$site_nama = 'SXTSQUAD'; // Name Website
$title = 'Free Download Video & MP3'; // Title Website
$desc = 'Free Download Video & MP3 just on Free Video SCH'; // Desc Website
$kword = 'Download Video, Download MP3, FREE MP3, download video gratis, dangdut, pop, rock, reggae, Video Gratis, Funny Video, YouTube'; // Keyword
$domain_name = 'www.sxtsquad.com'; // domain name - no need http:// or https://
$alamat_email = 'admin@sxtsquad.com'; //email contact
$fakedownload = 'http://1idsly.com/G04ds9tzIs'; //Fake Download
?>