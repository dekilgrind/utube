<center>
<div class="list-a">
    <!-- Safelinku.com Full Page Script Exclude-->
<script type="text/javascript">
    var go_url = 'https://idsly.bid/';
    var api = '5e41f6bbecb97e9e868b284457cc38d452969d28';
    var shorten_exclude = ['google.com', 'sxtsquad.com']; 
</script>
<script src='https://rawcdn.githack.com/riandiramdani/safelinku.com/dfea660cf01dddb004f50c30a69b4d2e58157e34/script.js'></script>
<!-- Safelinku.com Full Page Script Exclude-->

    

	
</div>
</center>