<?php include'EDIT.php';include'func.php';$title='DMCA '.$title.' - '.$site_nama.'';include'head.php';
echo'<h2 class="razdl">DIGITAL MILLENNIUM COPYRIGHTS ACT (DMCA)</h2>';echo'<div class="list-a">
<ul>
<h3>DMCA：</h3>
<p>If you think there is any problem with the video and you want to remove the video please report to <a href="https://www.youtube.com/reportabuse" target="_blank">Youtube</a>. We do not host any content in our website. Everything is served by <a href="https://www.youtube.com/reportabuse" target="_blank">Youtube</a> and data provide via Youtube API v3.</p>
<p>We only provide the search results derived from the Youtube API v3</p>
<p>But we respect you concerns and if you want your videos to be removed from our website search result listing please use <a href="./contact">contact form</a> to send us message.</p>
<p>You may also send the email to admin@topsell.co.id for faster processing.</p>
<p>After receiving the request, we will remove the search results as soon as possible.</p>

<br>
<h3>Disclaimer:</h3>
<p>All the content posted here is provided by Youtube using Youtube API v3.</p>
<p>We do not hold any copyright of the content posted here. No file is hosted on the server of TOPSELL. All material is served from the Youtube Server</p>
<p>Youtube is the registered trademark of Youtube LLC, a subsidiary of Google.</p>
<p>This website does NOT anything to do with Google Inc, vimeo, metacafe, dailymotion. Every trade marks are property of his owners. All videos are hosted on external servers, we use this API from Youtube to display videos. We simply provide a service to download videos to your computer for free. Dailymotion, Megavideo, Metacafe, Vimeo and Youtube videos are not hosted on TOPSELL. We don`t condone use of the site to download copyrighted material without consent.</p>
</ul>    
</div>';echo'<h2 class="razdl">Last Search</h2><div class="list-a">';include 'hasilcari.php';echo '</div>';include 'footer.php';?>