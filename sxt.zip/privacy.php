<?php include'EDIT.php';include'func.php';$title='PRIVACY POLICY '.$title.' - '.$site_nama.'';include'head.php';
echo'<h2 class="razdl">SXTSQUAD PRIVACY POLICY </h2>';
echo'
<div class="list-a">
<ul><br><br>
<p>Privacy has become a major concern on the Internet. this website knows that you care how information about you is used and shared. This privacy statement describes how this website deals with your information. By visiting this website, you are accepting the practices described in this privacy statement.</p>
<br>
<h3>Personal Information</h3>
<p>this website does not require you to disclose personal information anywhere on the site. Your IP address is used to gather broad demographic information and to track your general visiting patterns. Your IP address is also used to help diagnose technical problems. this website does not sell, rent, or trade your personal information with any third parties.</p>
<br>
<h3>Cookies</h3>
<p>Cookies are small text files that are used by many sites to store or transfer information between the main site and the computer you use to access the site. These cookies are stored in a special folder in your temporary internet files directory. this website uses cookies in parts of the website. In the course of serving advertisements to this site, our third-party advertiser may place or recognize a unique "cookie" on your browser.
</p>
<br>
<h3>Advertisers</h3>
<p>We use third-party advertising companies to serve ads when you visit this website. These companies may use information about your visits to this and other websites in order to provide advertisements on this site and other sites about goods and services that may be of interest to you. The advertisements may contain cookies. The advertisements are necessary to finance the costs of keeping this site online.</p>
<br>
<h3>Contact</h3>
<p>If you have any questions about this privacy statement, the practices of this site, or your dealings with this website, you are welcome to <a href="./contact">Contact US</a>.</p>
</ul>    
</div>';echo'<h2 class="razdl">Last Search</h2><div class="list-a">';include 'hasilcari.php';echo '</div>';include 'footer.php';?>